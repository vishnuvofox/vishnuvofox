import{j as e,a_ as t}from"./vendor-ac6fcfdf.js";import{S as r}from"./components-fee8c5d0.js";const s=()=>e(n,{children:e(r,{})}),n=t.div`
  height: calc(100vh - 220px);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  min-height: 320px;
`,m=t.p`
  font-size: 1rem;
  line-height: 1.5;
  margin: 0.625rem 0 1.5rem 0;
`;export{m as P,s as default};
